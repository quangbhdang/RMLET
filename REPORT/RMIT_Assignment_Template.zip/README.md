# Note:

This template was created based on the instructions from Overleaf for creating a beautiful paper on LaTex.

Highly recommend checking out this https://youtu.be/Jp0lPj2-DQA?si=mmggaoEQLgIz_4_Z playlist from Dr Trevor Barzett to help you improve your LaTex skills.

Otherwise, feel free to reach out to me at anda32664@gmail.com if you have any questions related to this template.